<?php

namespace App\Filament\Resources;

use App\Filament\Actions\ManageProjectPageAction;
use App\Filament\Resources\ProjectResource\Pages;
use App\Models\Project;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class ProjectResource extends Resource
{
    protected static ?string $model = Project::class;

    protected static ?string $navigationIcon = 'heroicon-o-folder';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                // Your existing form fields
                Forms\Components\TextInput::make('name')
                    ->required()
                    ->maxLength(255),
                
                Forms\Components\Textarea::make('description')
                    ->rows(3),
                
                Forms\Components\MarkdownEditor::make('content')
                    ->columnSpanFull(),
                
                // ... other fields
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')
                    ->searchable()
                    ->sortable(),
                
                Tables\Columns\TextColumn::make('description')
                    ->limit(50)
                    ->searchable(),
                
                // Add page status indicator
                Tables\Columns\IconColumn::make('page.is_published')
                    ->label('Page')
                    ->boolean()
                    ->trueIcon('heroicon-o-check-circle')
                    ->falseIcon('heroicon-o-x-circle')
                    ->trueColor('success')
                    ->falseColor('danger')
                    ->getStateUsing(fn ($record) => $record->page?->is_published ?? false),
                
                Tables\Columns\TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                
                Tables\Columns\TextColumn::make('updated_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                // Add filter for projects with/without pages
                Tables\Filters\TernaryFilter::make('has_page')
                    ->label('Has Project Page')
                    ->placeholder('All projects')
                    ->trueLabel('With page')
                    ->falseLabel('Without page')
                    ->queries(
                        true: fn ($query) => $query->has('page'),
                        false: fn ($query) => $query->doesntHave('page'),
                    ),
                
                Tables\Filters\TernaryFilter::make('page_published')
                    ->label('Page Published')
                    ->placeholder('All')
                    ->trueLabel('Published')
                    ->falseLabel('Draft')
                    ->queries(
                        true: fn ($query) => $query->whereHas('page', fn ($q) => $q->where('is_published', true)),
                        false: fn ($query) => $query->whereHas('page', fn ($q) => $q->where('is_published', false)),
                    ),
            ])
            ->actions([
                // Project page actions (add these FIRST)
                Tables\Actions\ActionGroup::make([
                    ManageProjectPageAction::viewPageAction(),
                    ManageProjectPageAction::make(),
                    ManageProjectPageAction::deletePageAction(),
                ])
                    ->label('Page')
                    ->icon('heroicon-o-document-text')
                    ->color('info')
                    ->button(),
                
                // Your existing actions
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                    
                    // Bulk action to generate pages
                    Tables\Actions\BulkAction::make('generatePages')
                        ->label('Generate Pages')
                        ->icon('heroicon-o-plus-circle')
                        ->color('success')
                        ->requiresConfirmation()
                        ->action(function ($records) {
                            $created = 0;
                            $skipped = 0;
                            
                            foreach ($records as $project) {
                                if ($project->page()->exists()) {
                                    $skipped++;
                                    continue;
                                }
                                
                                \App\Models\ProjectPage::create([
                                    'project_id' => $project->id,
                                    'slug' => \App\Models\ProjectPage::generateSlug($project->name),
                                    'is_published' => true,
                                ]);
                                
                                $created++;
                            }
                            
                            \Filament\Notifications\Notification::make()
                                ->title("Generated {$created} page(s)")
                                ->success()
                                ->body($skipped > 0 ? "Skipped {$skipped} project(s) that already have pages." : null)
                                ->send();
                        }),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            // Your existing relations
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListProjects::route('/'),
            'create' => Pages\CreateProject::route('/create'),
            'edit' => Pages\EditProject::route('/{record}/edit'),
        ];
    }
}
